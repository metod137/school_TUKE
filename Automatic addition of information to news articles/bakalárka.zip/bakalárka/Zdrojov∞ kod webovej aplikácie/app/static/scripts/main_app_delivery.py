print("loading...\n")

import requests
from bs4 import BeautifulSoup
from transformers import pipeline
import time
import concurrent.futures as cf
from progress.bar import Bar #pip install progress

def extract_entities(text):
    """
    SLOVAK MODEL - NER

    input arg: text - text článkov
    returns: output - výsledný zoznam entít
    """
    # vytvorenie pipeline pre NER s modelom crabz/slovakbert-ner 
    ner_pipeline = pipeline(task='ner', model='crabz/slovakbert-ner')

    # spracovanie textu pomocou pipeline pre NER
    classifications = ner_pipeline(text)

    # vytvorenie mapy, ktorá priraďuje jednotlivým typom entít číselné hodnoty
    ner_map = {0: '0', 1: 'B-OSOBA', 2: 'I-OSOBA', 3: 'B-ORGANIZÁCIA', 4: 'I-ORGANIZÁCIA', 5: 'B-LOKALITA', 6: 'I-LOKALITA'}

    # vytvorenie zoznamu s menovanými entítami
    entities = []
    for i in range(len(classifications)):
        if classifications[i]['entity'] != 0:
            if ner_map[classifications[i]['entity']][0] == 'B':
                j = i + 1
                while j < len(classifications) and ner_map[classifications[j]['entity']][0] == 'I':
                    j += 1
                entities.append((ner_map[classifications[i]['entity']].split('-')[1], classifications[i]['start'],classifications[j - 1]['end']))

    # vytvorenie nového zoznamu s menovanými entítami, kde každá entita je reprezentovaná len jednou pozíciou
    updated_entities = []
    i = 0
    while (i < len(entities)):
        entity = entities[i]
        for k in range(i, len(entities)-1):
            if entity[2] == entities[k+1][1]:
                entity = (entity[0],entity[1], entities[k+1][2])
                i += 1
            else:
                break
        updated_entities.append(entity)
        i += 1

    
    # vytvorenie výstupného slovníka s menovanými entítami a nepisanim duplikatov
    opakujuce_slova = set()
    output = {"TEXT VEDÚCEHO ČLÁNKU": text, "Output":{ "OSOBA":[], "ORGANIZÁCIA":[], "LOKALITA":[]}}
    
    for e in updated_entities:
        entity_text = text[e[1]:e[2]]
        if entity_text not in opakujuce_slova:
            opakujuce_slova.add(entity_text)
            output["Output"][e[0]].append(entity_text)

    return output

def get_article_from_aktualitySk(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """

    # vytvorenie requestu na url veduceho članku .... 
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")

    # hladanie textu článku na portali 
    article_content = soup.find(id="articleContent") or soup.find(id="article-content-body")
    article_text = article_content.get_text()

    return article_text

def generate_entities(args):
    """
    Volá funkciu extract_entities() a vloží jej odpoveď do slovníka 
    """
    bar = args[0]
    article = args[1]

    article['named_entities'] = extract_entities(article["text"])
    bar.next()

    return article

def process_denniknSK():
    ## zoznam článkov dennik N
    articles_dennikn = []

    with requests.Session() as session:
        url = 'https://dennikn.sk/'
        page = session.get(url)
        soup = BeautifulSoup(page.text, 'html.parser')

        ## Prechádzanie cez všetky články na webovej stránke
        for article in soup.select('div.tile_wrapper'):
            title = article.select_one('.tile_title a').text
            link = article.select_one('.tile_title a')['href']
        
            ## Uloženie údajov o článku do zoznamu
            articles_dennikn.append({
                'title': title.strip(),
                'link': link                
            })

        bar = Bar("Scrapovanie dennikn.sk", max=len(articles_dennikn))

        def _get_articles_from_dennkinSk(article : dict):
            # Otvorenie odkazu na článok
            article_page = session.get(article['link'])
            # Parsovanie HTML stránky pomocou BeautifulSoup
            article_soup = BeautifulSoup(article_page.text, 'html.parser')
            # Vyhľadanie elementov s textom článku
            article_text_elements = article_soup.select('.g_c.g_c__tiny p')
            # Získanie textu z elementov
            article_text = '\n'.join([element.text for element in article_text_elements])
            # Pridanie textu do slovníka s informáciami o článku
            article['text'] = article_text
            bar.next()

        with cf.ThreadPoolExecutor() as exec:
            exec.map(_get_articles_from_dennkinSk, articles_dennikn)

        bar.finish()

    ##filtrovanie článkov ktoré nemaju text
    articles_dennikn = list(filter(lambda article: article["text"].strip() != "", articles_dennikn))
    ##vytvorenie progress baru
    bar = Bar('Extrahovanie entít z Dennika N', max=len(articles_dennikn))
    
    articles_dennikn = [(bar, article) for article in articles_dennikn]

    with cf.ThreadPoolExecutor(max_workers=4) as exec: #I chose max_workers to be 4, because too many heavy threads are slowing each other
        articles_dennikn = exec.map(generate_entities, articles_dennikn)
    bar.finish()

    return articles_dennikn

def process_smeSK():
    articles_sme = []

    with requests.Session() as session:
        url = 'https://www.sme.sk/'
        response = session.get(url)
        soup = BeautifulSoup(response.text, "html.parser")

        h2 = soup.find_all("h2", class_="media-heading")
        for i in h2:
            title = i.text
            link = i.a.get("href")
            articles_sme.append({
                'title': title.strip(),
                'link': link                
            })

        bar = Bar("Scrapovanie sme.sk", max=len(articles_sme))

        def _get_articles_from_smeSk(article : dict):
            # Otvorenie odkazu na článok
            article_page = session.get(article['link'])
            # Parsovanie HTML stránky pomocou BeautifulSoup
            article_soup = BeautifulSoup(article_page.text, 'html.parser')
            left_panel = article_soup.find("article", id="js-article")
            if left_panel is not None:
                article_text = left_panel.text
            else:
                article_text = ""
            article['text'] = article_text
            bar.next()

        with cf.ThreadPoolExecutor() as exec:
            exec.map(_get_articles_from_smeSk, articles_sme)

        bar.finish()
    
    ##filtrovanie článkov, ktoré nemaju text
    articles_sme = list(filter(lambda article: article["text"].strip() != "", articles_sme))
    ##vytvorenie progress baru
    bar = Bar('Extrahovanie entit z Denník SME', max=len(articles_sme))
    
    articles_sme = [(bar, article) for article in articles_sme]

    with cf.ThreadPoolExecutor(max_workers=4) as exec: #hodnota max_workers na 4, pretože príliš veľa vlákien spomaľuje jeden druhého
        articles_sme = exec.map(generate_entities, articles_sme)
    bar.finish()

    return articles_sme

def filter_on_similar_articles(lead_article_name_entities, other_articles):
    output = []

    set_of_osoba = set(lead_article_name_entities['Output']['OSOBA'])
    set_of_organizacia = set(lead_article_name_entities['Output']['ORGANIZÁCIA'])
    set_of_lokalita = set(lead_article_name_entities['Output']['LOKALITA'])
    
    for article in other_articles:
        a = len(set_of_osoba.intersection(set(article['named_entities']['Output']['OSOBA'])))
        b = len(set_of_organizacia.intersection(set(article['named_entities']['Output']['ORGANIZÁCIA'])))
        c = len(set_of_lokalita.intersection(set(article['named_entities']['Output']['LOKALITA'])))

        if (a+b+c)>=2: #určenie kolko spoločných entit je dostatok na určenie, že ide o podobný článok
            output.append(f"{article['title']} - {article['link']}~")

    return output

def main():
    #region: WEB SCRAPE VEDUCEHO ČLANKU z portalu AKTUALITY
        #url článku
        url = input("\nVlož URL adresu z portálu aktuality.sk: ")

        #checking if url from aktuality.sk
        if "aktuality.sk" not in url:
            print("\nNeplatná URL adresa")
            return

        article_text = get_article_from_aktualitySk(url)
        print(f"\n✓ Vedúci článok je spracovaný\n")

        #zavolanie funkcie pre extrakciu menovaných entít
        named_entities = extract_entities(article_text)
        print(f"✓ Entity veduceho článku\n")
    #endregion

    #region: spracovanie dennikov
        article_dennikn = process_denniknSK()
        articles_sme = process_smeSK()
    #endregion

    #region: porovnanie podobnosti:
        results_dennikn = filter_on_similar_articles(named_entities, article_dennikn)
        results_sme = filter_on_similar_articles(named_entities, articles_sme)
        results = results_dennikn + results_sme
        if len(results)>0:
            print("\nPodobné články::")
            for result in results:
                print(result)
        else:
            print("\n🔴 Žiadny podobný článok 🔴")
    #endregion


if __name__ == "__main__":
    
    print("--------------------------------------")
    print("|        ARTICLE PAIRING APP         |")
    print("--------------------------------------")

    start = time.perf_counter()
    main()
    end = time.perf_counter()
    print(f"Finished in {end - start : .2f}s")