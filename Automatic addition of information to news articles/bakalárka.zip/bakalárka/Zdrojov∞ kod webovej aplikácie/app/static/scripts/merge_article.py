import spacy
import re

# Načítanie modelov
nlp_ner = spacy.load("sk_core_web_md")

def merges_two_articles(first_article, second_article):
  main_article = first_article
  article = second_article
  main_article += ' '
  article += ' '
  main_article = re.split(r'(?<=[a-zA-Z])\. ', main_article)
  del main_article[-1]
  article = re.split(r'(?<=[a-zA-Z])\. ', article)
  del article[-1]
  #print(main_article)
  x, y = 0, 0
  merges = {}
  for sentence in main_article:
      sentences = []  
      sent_nlp = nlp_ner(sentence)
      similarity_max = 0        

      for sentence2 in article:
          sent2_nlp = nlp_ner(sentence2)
          similarity = sent_nlp.similarity(sent2_nlp)
          if main_article.index(sentence) == article.index(sentence2):
            similarity += 0.2
          elif (main_article.index(sentence) + 1) == article.index(sentence2) or (main_article.index(sentence) - 1) == article.index(sentence2):
            similarity += 0.04   

          if similarity > similarity_max:
              similarity_max = similarity
              sentences = [sentence, sentence2, similarity] 
      merges[x] = sentences 
      if len(sentences) == 0:
        merges[x] = [sentence, '-', 0]
      x += 1
      if len(sentences) != 0:
        article.remove(sentences[1])

  print(merges)
  #print(len(sent2))
  result = "" 
  for x in merges:
    if len(merges[x][0]) > len(merges[x][1]):
      result += merges[x][0] + '. '
    else:
      result += merges[x][1] + '. '
  """
  values = [item[2] for item in merges.values()]
  if sum(values) != 0 or len(values) != 0:
    average = sum(values) / len(values)
  else:
    average = 0
  """
  average = 3.6
  return [result, article, average]

def merges_missing_info(result, mising, origo):
  #print(result)
  #print('\n')
  text = result
  #print(text)
  #print('\n')
  text += ' '
  text = re.split(r'(?<=[a-zA-Z])\. ', text)
  origo += ' '
  origo = re.split(r'(?<=[a-zA-Z])\. ', origo)
  del origo[-1]
  del text[-1]
  for x in mising:
    text.insert(origo.index(x), x)
  result2 = ""
  for x in text:
    result2 += x + '. '
  #print(result2)
  #print('\n')
  return result2

def merges_articles(main_article, article_list):
  merges = []
  article_min = []
  value = 103
  for article in article_list:
    merges.append(merges_two_articles(main_article, article))
  #print(merges)
  #print('\n')
  for min in merges:
    if min[2] < value:
      value = min[2]
      article_min = min
  article2 = article_min[0]
  for mising, original_article in zip(merges, article_list):
    article2 = merges_missing_info(article2, mising[1], original_article)
  """
  articles = []
  articles.append(main_article)
  for x in article_list:
    articles.append(x)
  print(indexing_articels(articles, article2))
  """
  return article2

def indexing_articels(articles, article_finall):
  colors = [[255, 0, 0], [0, 255, 0], [0, 0, 255]]   
  result = []
  split_articles = [] 
  for article in articles:
    article += ' '
    article = re.split(r'(?<=[a-zA-Z])\. ', article)
    del article[-1]
    split_articles.append(article)  
  article_finall += ' '
  article_finall = re.split(r'(?<=[a-zA-Z])\. ', article_finall)
  del article_finall[-1]
  for y in article_finall:
    for i, x in enumerate(split_articles): 
      if y in x:
        result.append([y, colors[i]])
  print(result)
  return result

def colored_links(urls):
  colors = [[255, 0, 0], [0, 255, 0], [0, 0, 255]]
  result = []
  for x in range(0, len(urls)):
    result.append([urls[x], colors[x]])
  
  return result

"""
sent = "Gruzínska prezidentka Salome Zurabišviliová tvrdí, že načasovanie oznámenia smrti ruského opozičného lídra Alexeja Navaľného nebola náhoda, ale posolstvo zo strany ruského režimu. Povedala to v nedeľu na okraj Mníchovskej bezpečnostnej konferencie, píše TASR podľa agentúry DPA. „Myslím si, že to nebola náhoda, že smrť Navaľného bola oznámená niekoľko hodín či len minút pred začiatkom mníchovskej konferencie, povedala DPA 71-ročná Zurabišviliová. Dodala, že je už akoby „povahovou črtou v správaní Ruska, že sa snaží ukázať, že si robí čo chce a kedy chce. Podľa nej bol pritom práve toto aj odkaz, ktorý tým chcel Kremeľ vyslať mníchovskej bezpečnostnej konferencii. Po vychádzke Navaľnému údajne prišlo nevoľno a okamžite stratil vedomie. Privolaní zdravotníci z nemocnice v meste Labytnangi sa ho vraj pokúšali oživovať viac ako pol hodiny, ale neúspešne. Na mnohých miesta v Rusku sa v piatok a sobotu konali spontánne zhromaždenia na pamiatku Navaľného. Bezpečnostné zložky na nich zadržali najmenej 401. ľudí, najviac v Petrohrade a Moskve, vyplýva z najnovších údajov mimovládne organizácie OVD-Info monitorujúcej zatýkania na nepovolených podujatiach v Rusku. Navaľnyj bol jedným z najvýraznejších kritikov režimu Vladimira Putina, pričom sa mu podarilo vyburcovať rozsiahle protesty, a to aj napriek prísnym ruským zákonom cieleným proti demonštráciám. Uväznili ho na začiatku roka 2021 po tom, ako sa do Ruska vrátil z Nemecka, kde sa zotavoval z otravy nervovoparalytickou látkou novičok, z ktorej obviňoval Kremeľ."
sent2 = "MNÍCHOV. Gruzínska prezidentka Salome Zurabišviliová tvrdí, že načasovanie oznámenia smrti ruského opozičného lídra Alexeja Navaľného nebola náhoda, ale posolstvo zo strany ruského režimu. Povedala to v nedeľu na okraj Mníchovskej bezpečnostnej konferencie. Myslím si, že to nebola náhoda, že smrť Navaľného bola oznámená niekoľko hodín či len minút pred začiatkom mníchovskej konferencie, povedala DPA 71-ročná Zurabišviliová. Dodala, že je už akoby povahovou črtou v správaní Ruska, že sa snaží ukázať, že si robí čo chce a kedy chce. Podľa nej bol pritom práve toto aj odkaz, ktorý tým chcel Kremeľ vyslať mníchovskej bezpečnostnej konferencii. O úmrtí Navaľného v trestaneckej kolónii IK-3 za polárnym kruhom informovala v piatok ruská väzenská služba. Po vychádzke mu údajne prišlo nevoľno a okamžite stratil vedomie. Privolaní zdravotníci z nemocnice v meste Labytnangi sa ho vraj pokúšali oživovať viac ako pol hodiny, ale neúspešne. Na mnohých miesta v Rusku sa v piatok a sobotu konali spontánne zhromaždenia na pamiatku Navaľného. Bezpečnostné zložky na nich zadržali najmenej 401 ľudí, najviac v Petrohrade a Moskve, vyplýva z najnovších údajov mimovládne organizácie OVD-Info monitorujúcej zatýkania na nepovolených podujatiach v Rusku. Navaľnyj bol jedným z najvýraznejších kritikov režimu Vladimira Putina, pričom sa mu podarilo vyburcovať rozsiahle protesty, a to aj napriek prísnym ruským zákonom cieleným proti demonštráciám. Uväznili ho na začiatku roka 2021 po tom, ako sa do Ruska vrátil z Nemecka, kde sa zotavoval z otravy nervovoparalytickou látkou novičok, z ktorej obviňoval Kremeľ."
sent3 = "V auguste 2020 sa Alexeja Navaľného pokúsila zabiť ruská spravodajská služba FSB. Počas letu z Moskvy do Sibíri pred regionálnymi voľbami mu prišlo zle, ale život mu zachránil pilot, ktorý pohotovo pristál v Omsku. Významného odporcu prezidenta Vladimira Putina následne previezli do Berlína, kde potvrdili, že ho otrávili novičkom. Navaľnyj vedel, že ak sa vráti do Ruska, okamžite ho zatknú pre vykonštruované obvinenie z finančného podvodu. Napriek tomu to päť mesiacov po neúspešnom atentáte urobil. Odvtedy bol Navaľnyj s vážne nalomeným zdravím vo väzení, pričom ho až 27-krát poslali na samotku. Celkovo tu strávil 300 dní. Posledné mesiace ho väznili v jednej z najsevernejších trestaneckých kolónií v Jamalsku za polárnym kruhom. V piatok vo veku 47 rokov podľa ruských úradov zomrel, Navaľného spolupracovníci to zatiaľ nepotvrdili. „Hoci správy o Navaľného smrti naozaj vyzerajú vážne, rozhodne by som o jeho smrti radšej nehovoril ako o dokázanom fakte, kým nebudem mať úplné potvrdenie – aj z etických dôvodov,“ povedal pre Denník N bývalý minister energetiky Vladimir Milov, ktorý sa označuje za Navaľného priateľa. Podľa ruských médií stratil vedomie počas prechádzky a lekári ho už nedokázali oživiť. Príčinou smrti je podľa ruských médií krvná zrazenina. Informácia o Navaľného smrti sa pritom na stránke väzenskej služby v Jamalsku objavila už dve minúty po tom, čo sa údajne udiala. Opozičný politik vraj zomrel o 14.17 a už o 14.19 služba zverejnila tlačovú správu. „Úrady nikdy nereagujú takto rýchlo, obzvlášť, pokiaľ ide o smrť väzňov,“ píše ukrajinský analytik Anton Geraščenko. „Putin dnes konečne zabil Navaľného,“ píše novinár Christo Grozev z investigatívneho projektu Bellingcat."
urls = []
urls.append(sent2)
#urls.append(sent3)

result = merges_articles(sent, urls)
print(result)
"""