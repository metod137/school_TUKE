import requests
from bs4 import BeautifulSoup
import time
import concurrent.futures as cf
from sklearn.metrics.pairwise import cosine_similarity
import csv



def get_article_content_from_aktualitySk(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """
    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")
    advertising3 = ""
    if soup.find("div", {"class": "fulltext"}) is not None:
      advertising = soup.find("div", {"class": "blocker-container thanks-blocker-container"})
      if advertising is not None:
        advertising = advertising.find_all('p')
        for x in advertising:
          advertising3 += x.text
    article_content = soup.find("div", {"class": "fulltext"})
    paragraphs = ""
    if article_content:
      paragraphs = article_content.find_all('p')
    paragraphs2 = ""
    for x in paragraphs:
      paragraphs2 += x.text
    return paragraphs2.replace(advertising3, "")

def get_article_content_from_Dennikn(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """

    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")
    article_content = soup.find("div", {"class": "a_single__default"})
    paragraphs = ""
    if article_content:
      paragraphs = article_content.find_all('p')
    paragraphs2 = ""
    for x in paragraphs:
      paragraphs2 += x.text
    return str(paragraphs2)


def get_article_content_from_Sme(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """
    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")

    article_content = soup.find(id="js-article")
    paragraphs = ""
    if article_content:
      paragraphs = article_content.find_all('p')
    paragraphs2 = ""
    for x in paragraphs:
      paragraphs2 += x.text
    return paragraphs2


#print(get_article_content_from_Sme("https://tech.sme.sk/c/23282619/pozname-ho-ako-chorobu-minulosti-bubonicky-mor-vsak-ludi-ohrozuje-aj-v-roku-2024.html"))
#print(get_article_content_from_aktualitySk("https://www.aktuality.sk/clanok/mhjA13r/na-slovenskych-horach-hrozia-laviny-v-pohoriach-ich-moze-zapricinit-previaty-a-mokry-sneh/"))
#print(get_article_content_from_Dennikn("https://dennikn.sk/3846416/marian-lesko-toto-je-brutalny-utok-na-nasu-ustavnost/?ref=tit~"))