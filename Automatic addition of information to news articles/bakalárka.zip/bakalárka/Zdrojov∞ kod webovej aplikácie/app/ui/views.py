import re

from django.shortcuts import render, redirect, reverse, get_object_or_404
from django.http import HttpResponseRedirect
from .models import Article
from static.scripts import main_app_delivery, import_article, merge_article
from django.contrib import messages
import time


class URL:
    def __init__(self, url):
        self._url = url

    def get_url(self):
        return self._url

    def set_url(self, new_url):
        self._url = new_url


store_url = URL('https://www.aktuality.sk/')


def script_call(url):
    get_text = main_app_delivery.get_article_from_aktualitySk(url)
    extracted = main_app_delivery.extract_entities(get_text)
    article_dennikn = main_app_delivery.process_denniknSK()
    articles_sme = main_app_delivery.process_smeSK()
    results_dennikn = main_app_delivery.filter_on_similar_articles(extracted, article_dennikn)
    results_sme = main_app_delivery.filter_on_similar_articles(extracted, articles_sme)
    results = results_dennikn + results_sme
    return results

def HomeView(request):
    if request.method == 'POST':
        url = request.POST.get('url')
        if "aktuality.sk" in url:

            store_url.set_url(url)

            exist = Article.objects.filter(url=url).exists()

            if (exist):
                article = get_object_or_404(Article, url=url)
                if article.response == 'notfound':
                    return redirect('NotFoundTaskView')
                else:
                    return redirect('ChooseArticlesTaskView')
            else:
                article = Article(url=url)
                article.save()
                return redirect('TaskView')

        else:
            messages.success(request, 'Make sure to have an article from aktuality.sk')
            return render(request, 'index.html')

    return render(request, 'index.html')


def ChooseArticlesTaskView(request):
    
    url = store_url.get_url()
    article_response = get_object_or_404(Article, url=url)

    urls = re.findall(r'(https?://\S+)', article_response.response)
    
    context = {
        'article': article_response,
        'urls': urls
        #'content' : urls[1] if urls else None
    }
    return render(request, 'ChooseArticlesTaskView.html', context)


def TaskView(request):
    url = store_url.get_url()

    results = script_call(url)

    article = get_object_or_404(Article, url=url)

    if len(results) > 0:
        article.response = '\n'.join(results)  # oddelovač riadkov je nový riadok
        article.save()
        return redirect('success.html')
    else:
        article.response = 'notfound'
        article.save()
        return redirect('NotFoundTaskView')

    return render(request, 'task.html')


def SuccessTaskView(request):
    url = store_url.get_url()
    selected_urls = []
    urls = []
    if request.method == 'POST':
        # Získať hodnoty odškrtnutých checkboxov z POST dát
        selected_urls += request.POST.getlist("url")
        #print(selected_urls)
        #print('\n')
    for article in selected_urls:
        if "aktuality.sk" in article:
            urls.append(import_article.get_article_content_from_aktualitySk(article))
        elif "dennikn.sk" in article:
            urls.append(import_article.get_article_content_from_Dennikn(article))
        elif "sme.sk" in article:
            urls.append(import_article.get_article_content_from_Sme(article))
    
    #print(url)
    #print('\n')
    #print(urls)
    #print('\n')
    url_text = import_article.get_article_content_from_aktualitySk(url)
    selected_urls.insert(0, url)
    print(selected_urls[0])
    #print(url_text)
    #url_text = "Gruzínska prezidentka Salome Zurabišviliová tvrdí, že načasovanie oznámenia smrti ruského opozičného lídra Alexeja Navaľného nebola náhoda, ale posolstvo zo strany ruského režimu. Povedala to v nedeľu na okraj Mníchovskej bezpečnostnej konferencie, píše TASR podľa agentúry DPA. „Myslím si, že to nebola náhoda, že smrť Navaľného bola oznámená niekoľko hodín či len minút pred začiatkom mníchovskej konferencie, povedala DPA 71-ročná Zurabišviliová. Dodala, že je už akoby „povahovou črtou v správaní Ruska, že sa snaží ukázať, že si robí čo chce a kedy chce. Podľa nej bol pritom práve toto aj odkaz, ktorý tým chcel Kremeľ vyslať mníchovskej bezpečnostnej konferencii. Po vychádzke Navaľnému údajne prišlo nevoľno a okamžite stratil vedomie. Privolaní zdravotníci z nemocnice v meste Labytnangi sa ho vraj pokúšali oživovať viac ako pol hodiny, ale neúspešne. Na mnohých miesta v Rusku sa v piatok a sobotu konali spontánne zhromaždenia na pamiatku Navaľného. Bezpečnostné zložky na nich zadržali najmenej 401 ľudí, najviac v Petrohrade a Moskve, vyplýva z najnovších údajov mimovládne organizácie OVD-Info monitorujúcej zatýkania na nepovolených podujatiach v Rusku. Navaľnyj bol jedným z najvýraznejších kritikov režimu Vladimira Putina, pričom sa mu podarilo vyburcovať rozsiahle protesty, a to aj napriek prísnym ruským zákonom cieleným proti demonštráciám. Uväznili ho na začiatku roka 2021 po tom, ako sa do Ruska vrátil z Nemecka, kde sa zotavoval z otravy nervovoparalytickou látkou novičok, z ktorej obviňoval Kremeľ."
    #urls.append("MNÍCHOV. Gruzínska prezidentka Salome Zurabišviliová tvrdí, že načasovanie oznámenia smrti ruského opozičného lídra Alexeja Navaľného nebola náhoda, ale posolstvo zo strany ruského režimu. Povedala to v nedeľu na okraj Mníchovskej bezpečnostnej konferencie. Myslím si, že to nebola náhoda, že smrť Navaľného bola oznámená niekoľko hodín či len minút pred začiatkom mníchovskej konferencie, povedala DPA 71-ročná Zurabišviliová. Dodala, že je už akoby povahovou črtou v správaní Ruska, že sa snaží ukázať, že si robí čo chce a kedy chce. Podľa nej bol pritom práve toto aj odkaz, ktorý tým chcel Kremeľ vyslať mníchovskej bezpečnostnej konferencii. O úmrtí Navaľného v trestaneckej kolónii IK-3 za polárnym kruhom informovala v piatok ruská väzenská služba. Po vychádzke mu údajne prišlo nevoľno a okamžite stratil vedomie. Privolaní zdravotníci z nemocnice v meste Labytnangi sa ho vraj pokúšali oživovať viac ako pol hodiny, ale neúspešne. Na mnohých miesta v Rusku sa v piatok a sobotu konali spontánne zhromaždenia na pamiatku Navaľného. Bezpečnostné zložky na nich zadržali najmenej 401 ľudí, najviac v Petrohrade a Moskve, vyplýva z najnovších údajov mimovládne organizácie OVD-Info monitorujúcej zatýkania na nepovolených podujatiach v Rusku. Navaľnyj bol jedným z najvýraznejších kritikov režimu Vladimira Putina, pričom sa mu podarilo vyburcovať rozsiahle protesty, a to aj napriek prísnym ruským zákonom cieleným proti demonštráciám. Uväznili ho na začiatku roka 2021 po tom, ako sa do Ruska vrátil z Nemecka, kde sa zotavoval z otravy nervovoparalytickou látkou novičok, z ktorej obviňoval Kremeľ.")
    #urls.append("V auguste 2020 sa Alexeja Navaľného pokúsila zabiť ruská spravodajská služba FSB. Počas letu z Moskvy do Sibíri pred regionálnymi voľbami mu prišlo zle, ale život mu zachránil pilot, ktorý pohotovo pristál v Omsku. Významného odporcu prezidenta Vladimira Putina následne previezli do Berlína, kde potvrdili, že ho otrávili novičkom. Navaľnyj vedel, že ak sa vráti do Ruska, okamžite ho zatknú pre vykonštruované obvinenie z finančného podvodu. Napriek tomu to päť mesiacov po neúspešnom atentáte urobil. Odvtedy bol Navaľnyj s vážne nalomeným zdravím vo väzení, pričom ho až 27-krát poslali na samotku. Celkovo tu strávil 300 dní. Posledné mesiace ho väznili v jednej z najsevernejších trestaneckých kolónií v Jamalsku za polárnym kruhom. V piatok vo veku 47 rokov podľa ruských úradov zomrel, Navaľného spolupracovníci to zatiaľ nepotvrdili. „Hoci správy o Navaľného smrti naozaj vyzerajú vážne, rozhodne by som o jeho smrti radšej nehovoril ako o dokázanom fakte, kým nebudem mať úplné potvrdenie – aj z etických dôvodov,“ povedal pre Denník N bývalý minister energetiky Vladimir Milov, ktorý sa označuje za Navaľného priateľa. Podľa ruských médií stratil vedomie počas prechádzky a lekári ho už nedokázali oživiť. Príčinou smrti je podľa ruských médií krvná zrazenina. Informácia o Navaľného smrti sa pritom na stránke väzenskej služby v Jamalsku objavila už dve minúty po tom, čo sa údajne udiala. Opozičný politik vraj zomrel o 14.17 a už o 14.19 služba zverejnila tlačovú správu. „Úrady nikdy nereagujú takto rýchlo, obzvlášť, pokiaľ ide o smrť väzňov,“ píše ukrajinský analytik Anton Geraščenko. „Putin dnes konečne zabil Navaľného,“ píše novinár Christo Grozev z investigatívneho projektu Bellingcat.")
    merges = merge_article.merges_articles(url_text, urls)
    urls_all = []
    for seconds_articles in urls:
        urls_all.append(seconds_articles)
    print(selected_urls)
    context = { 
        'merge': merges, 
        'urls_all': selected_urls
    }
    return render(request, 'success.html', context) 

def ColoredView(request):
    urls_all = []
    if request.method == 'POST':
        merge = request.POST.get('merge', '')  # Získaj hodnotu 'merge' z POST
        urls_all += request.POST.getlist("url")
          
    urls = []
    for article in urls_all:
        if "aktuality.sk" in article:
            urls.append(import_article.get_article_content_from_aktualitySk(article))
        elif "dennikn.sk" in article:
            urls.append(import_article.get_article_content_from_Dennikn(article))
        elif "sme.sk" in article:
            urls.append(import_article.get_article_content_from_Sme(article))   
    #print(urls) 
    results = merge_article.indexing_articels(urls, merge)
    urls_colors = merge_article.colored_links(urls_all)
    #print(urls_colors)
    context = {
        'results': results,
        'links' : urls_colors
    } 
    return render(request, 'ColoredView.html', context)    

def NotFoundTaskView(request):  
    return render(request, 'not-found.html')
 
#https://www.aktuality.sk/clanok/Orv3FLO/prezidentske-volby-2024-prve-kolo-prezidentskych-volieb-by-vo-februari-vyhral-peter-pellegrini-ukazal-prieskum/