from django.db import models

# Create your models here.



class Article(models.Model):

	url = models.CharField(max_length=500)  
	response = models.CharField(max_length=100000,null=True)

 