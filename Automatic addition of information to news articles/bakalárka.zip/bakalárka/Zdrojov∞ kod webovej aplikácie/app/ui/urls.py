from django.urls import path 
from . import views


urlpatterns = [ 
    
    path('',views.HomeView,name='HomeView'),
    path('task/', views.TaskView, name='TaskView'),
    path('success/', views.SuccessTaskView, name='SuccessTaskView'), 
    path('not_found/', views.NotFoundTaskView, name='NotFoundTaskView'),
    path('choose_articles/', views.ChooseArticlesTaskView, name='ChooseArticlesTaskView'),
    path('ColoredView/', views.ColoredView, name='ColoredView'), 
    
]