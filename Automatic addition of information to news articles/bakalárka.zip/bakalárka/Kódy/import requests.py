import requests
from bs4 import BeautifulSoup
import time
import concurrent.futures as cf
import spacy

# Načítanie modelov
nlp_ner = spacy.load("sk_core_web_md")

def merge_articles(article1 : str, article2 : str, article3 : str):

    doc1_ner = nlp_ner(article1)
    doc2_ner = nlp_ner(article2)
    doc3_ner = nlp_ner(article3)

    tokens_article1_ner = [token.text for token in doc1_ner]
    tokens_article2_ner = [token.text for token in doc2_ner]
    tokens_article3_ner = [token.text for token in doc3_ner]

    merged_tokens_ner = tokens_article1_ner + tokens_article2_ner + tokens_article3_ner

    merged_text_ner = " ".join(merged_tokens_ner)

    return merged_text_ner


def get_article_content_from_aktualitySk(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """

    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")
    article_content = soup.find("div", {"class": "fulltext"}).get_text()
    if soup.find("div", {"class": "fulltext"}) is not None:
      advertising = soup.find("div", {"class": "blocker-container thanks-blocker-container"}).get_text()
      article_content = article_content.replace(str(advertising), '')
    if soup.find("div", {"class": "article-object-item"}) is not None:
      advertising2 = soup.find("div", {"class": "article-object-item"}).get_text()
      article_content = article_content.replace(str(advertising2), '')

    return article_content

def get_article_content_from_Dennikn(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """

    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")

    if soup.find("div", {"class": "a_single__default"}) is None:
      article_content = soup.find("aside", {"class": "a_mpm a_mpm__single"}).get_text()
    else:
      article_content = soup.find("div", {"class": "a_single__default"}).get_text()
    if soup.find("div", {"class": "e_lock e_lock__hard e_lock__shade"}) is not None:
      advertising1 = soup.find("div", {"class": "e_lock e_lock__hard e_lock__shade"}).get_text()
      article_content = article_content.replace(str(advertising1), '')
    advertising2 = "Magyar verzió"
    article_content = article_content.replace(str(advertising2), '')
    return article_content


def get_article_content_from_Sme(url : str):
    """
    Získa článok zo zadaného URL a vráti jeho text
    """

    # vytvorenie requestu na url veduceho članku ....
    response = requests.get(url)
    soup = BeautifulSoup(response.content,"html.parser")

    article_content = soup.find(id="js-article").get_text()
    if soup.find("div", {"class": "share-box share-box-top relative cf"}) is not None:
      advertising1 = soup.find("div", {"class": "share-box share-box-top relative cf"}).get_text()
      article_content = article_content.replace(str(advertising1), '')
    if soup.find("a", {"class": "article-avizo article-avizo-spaceless"}) is not None:
      advertising2 = soup.find("a", {"class": "article-avizo article-avizo-spaceless"}).get_text()
      article_content = article_content.replace(str(advertising2), '')
    advertising3 = "SkryťVypnúť reklamu"
    article_content = article_content.replace(str(advertising3), '')
    if soup.find("div", {"class": "js-deep-container-promo-piano-article"}) is not None:
      advertising4 = soup.find("div", {"class": "js-deep-container-promo-piano-article"}).get_text()
      article_content = article_content.replace(str(advertising4), '')
    if soup.find("div", {"class": "js-deep-container-article-topic-box topic-box topic-box-article my-m hidden-print wf fl"}) is not None:
      advertising5 = soup.find("div", {"class": "js-deep-container-article-topic-box topic-box topic-box-article my-m hidden-print wf fl"}).get_text()
      article_content = article_content.replace(str(advertising5), '')
    advertising6 = "Článok pokračuje pod video reklamou"
    article_content = article_content.replace(str(advertising6), '')
    return article_content

url = "https://www.aktuality.sk/clanok/2kpfBty/arcibiskup-orosch-zavolal-na-novenu-aj-knaza-mariana-kuffu-v-kazni-obhajoval-svojho-brata/"
if len(url) == 0:
  article_text1 = ''
else:
  article_text1 = get_article_content_from_aktualitySk(url)
print(article_text1)
print("\n")

url = "https://dennikn.sk/3688433/politicka-put-stefana-kuffu-statneho-tajomnika-ktory-chce-liecit-homosexualitu-a-korunovat-krista/?ref=tit"
if len(url) == 0:
  article_text2 = ''
else:
  article_text2 = get_article_content_from_Dennikn(url)
print(article_text2)
print("\n")

url = ""
if len(url) == 0:
  article_text3 = ''
else:
  article_text3 = get_article_content_from_Sme(url)
print(article_text3)
print("\n")

merged_text = merge_articles(article_text1, article_text2, article_text3)
print(merged_text)